export enum TorqueProviderEvents {
  ProviderAvailable = "ProviderAvailable",
  ProviderChanged = "ProviderChanged",
  ProviderIsChanging = "ProviderIsChanging",
}
