export interface ICollateralManagementParams {
  minValue: number;
  maxValue: number;
  currentValue: number;
}
