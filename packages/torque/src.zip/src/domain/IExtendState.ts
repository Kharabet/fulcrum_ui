export interface IExtendState {
  minValue: number;
  maxValue: number;
  currentValue: number;
}
