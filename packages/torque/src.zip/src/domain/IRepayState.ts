export interface IRepayState {
  minValue: number;
  maxValue: number;
  currentValue: number;
}
