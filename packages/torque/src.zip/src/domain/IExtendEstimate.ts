import { BigNumber } from "@0x/utils";

export interface IExtendEstimate {
  depositAmount: BigNumber;
}
