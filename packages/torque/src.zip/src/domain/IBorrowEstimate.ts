import { BigNumber } from "@0x/utils";

export interface IBorrowEstimate {
  depositAmount: BigNumber;
  gasEstimate: BigNumber;
}
