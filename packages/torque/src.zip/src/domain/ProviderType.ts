export enum ProviderType {
  Alchemy = "Alchemy",
  MetaMask = "MetaMask",
  Bitski = "Bitski",
  Fortmatic = "Fortmatic",
  Portis = "Portis",
  WalletConnect = "WalletConnect",
  WalletLink = "WalletLink",
  Squarelink = "Squarelink",
  Torus = "Torus",
  None = "None"
}
