export enum Asset {
  ETH = "ETH",
  WETH = "ETH",
  SAI = "SAI",
  DAI = "DAI",
  USDC = "USDC",
  SUSD = "SUSD",
  WBTC = "WBTC",
  LINK = "LINK",
  MKR = "MKR",
  ZRX = "ZRX",
  BAT = "BAT",
  REP = "REP",
  KNC = "KNC",
  UNKNOWN = "UNKNOWN"
}

