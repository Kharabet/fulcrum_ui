export interface IWeb3ProviderSettings {
  networkId: number;
  networkName: string;
  etherscanURL: string;
}
