import { BigNumber } from "@0x/utils";

export interface IRepayEstimate {
  repayAmount: BigNumber;
  repayPercent?: number;
}
