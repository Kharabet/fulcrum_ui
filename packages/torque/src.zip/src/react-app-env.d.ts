/// <reference types="react-scripts" />
declare module 'react-tippy';
declare module 'node-fetch';
declare module 'react-intercom';